from flask import Flask, render_template
from reward_system import DharmaRewardSystem

app = Flask(__name__)
dharma = DharmaRewardSystem()

@app.route("/")
def dashboard():
    user = dharma.register_user("Arjun", "Student")
    dharma.log_action(user.user_id, "AttendClass")
    dharma.log_action(user.user_id, "Meditate")
    status = dharma.get_user_status(user.user_id)
    return render_template("dashboard.html", user=status)


if __name__ == "__main__":
    app.run(debug=True)
