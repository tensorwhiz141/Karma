from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class User:
    user_id: str
    name: str
    role: str
    karma_log: List[Dict] = field(default_factory=list)
    points: Dict[str, float] = field(default_factory=lambda: {
        "DharmaPoints": 0,
        "SevaCredits": 0,
        "PunyaTokens": 0
    })
