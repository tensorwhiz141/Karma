import uuid
from models import User

class DharmaRewardSystem:
    ACTION_VALUES = {
        "AttendClass": {"DharmaPoints": 10},
        "CompleteSeva": {"SevaCredits": 15, "DharmaPoints": 5},
        "Donate": {"PunyaTokens": 20},
        "ShareKnowledge": {"DharmaPoints": 15, "PunyaTokens": 5},
        "Meditate": {"DharmaPoints": 5}
    }

    RANK_TIERS = [
        (0, "Shraddhavan"),
        (100, "SevaYogi"),
        (200, "VedArthagnani"),
        (400, "Rishi")
    ]

    def __init__(self):
        self.users = {}

    def register_user(self, name, role):
        user_id = str(uuid.uuid4())
        user = User(user_id=user_id, name=name, role=role)
        self.users[user_id] = user
        return user

    def log_action(self, user_id, action):
        user = self.users[user_id]
        rewards = self.ACTION_VALUES.get(action, {})
        for token, value in rewards.items():
            user.points[token] += value
        user.karma_log.append({"action": action, "rewards": rewards})
        return rewards

    def get_user_status(self, user_id):
        user = self.users[user_id]
        total_dharma = user.points["DharmaPoints"]
        rank = max((rank for threshold, rank in self.RANK_TIERS if total_dharma >= threshold), key=lambda x: self.RANK_TIERS.index((threshold, x)))
        return {
            "Name": user.name,
            "Role": user.role,
            "Points": user.points,
            "Spiritual Rank": rank
        }
